# WARNING BEFORE TO START YOU NEED KNOWEDGE OF LINUX AND COMMANDLINE 


# IF YOU HAVE ERROR USING BINARY IN UBUNTU V20 TRY DOWNLAOD udpServer20Ubuntu from Downloads #

# INSTRUCTIONS #
# 1. FAST INSTALL 

##### SCRIPT AUTO INSTALL UDPREQUEST IN YOUR VPS By @Rufu99
Installer script  [INSTALL FROM HERE](https://github.com/rudi9999/SocksIP-udpServer/blob/main/README.md)

# 2.  INSTALL FROM SCRATCH #

# These commands have been tested on ubuntu 20 - 22 x64

First you need download binary [Download from here](https://bitbucket.org/iopmx/udprequestserver/downloads/)

##### RUN
`ufw disable`

##### RUN
`reboot`

After rebooted system go to worskpace where saved binary server UDP
before run command you need primary IP address of your server and network interface example on my server is 
##### Interface = enp1s0
##### IP = 59.66.45.2 

Ok now run server binary with next args.
`./udpServer  -ip=59.66.45.2  -net=enp1s0 -mode=system`

what does the arguments mean, keep it short the ip will be the primary address of your server the network interface the same but system mode means users can login using system users you can add your users via useradd or adduser like SSH this makes comptability easier

if your server started you can see Server started V2.0.1

##### NOTE: the version maybe change in the future. and if you need run in background you need search for self how to ;)
##### WHEN YOU ADD USER YOU NED MANDATORY ADD EXPIRE TIME TO USER example 
`useradd -e 2022-12-28 test`

the server is ready to use with the client in socksip.





